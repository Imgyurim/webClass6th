$(document).ready(function(){

    let slider1 = new Swiper(".station_sig",{
        slidesPerView : 3,
    })

    let slider2 = new Swiper(".station_bakery",{
        slidesPerView : 3,
    })

    let slider3 = new Swiper(".station_coffee",{
        slidesPerView : 3
    })
    
    let slider4 = new Swiper(".station_ade",{
        slidesPerView : 3
    })

    let slider5 = new Swiper(".station_doubleMilk",{
        slidesPerView : 3
    })

    let slider6 = new Swiper(".station_collaboration",{
        slidesPerView : 3
    })

})